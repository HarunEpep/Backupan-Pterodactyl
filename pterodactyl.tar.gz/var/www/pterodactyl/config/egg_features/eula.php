<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Egg Feature: EULA Popup
    |--------------------------------------------------------------------------
    |
    | This popup is enabled for Minecraft eggs and allows a custom frontend
    | hook to run that monitors the console output of the server and pops up
    | a modal asking the user to accept it if necessary.
    |
    | There is no additional configuration necessary.
    |
    */
];
