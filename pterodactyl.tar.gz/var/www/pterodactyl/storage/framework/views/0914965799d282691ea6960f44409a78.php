<?php $__env->startSection('container'); ?>
    <div id="modal-portal"></div>
    <div id="app"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-800'],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/pterodactyl/resources/views/templates/base/core.blade.php ENDPATH**/ ?>