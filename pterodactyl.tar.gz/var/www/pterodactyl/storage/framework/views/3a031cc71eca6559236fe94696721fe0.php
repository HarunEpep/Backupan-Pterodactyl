
<?php /**PATH /var/www/pterodactyl/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>